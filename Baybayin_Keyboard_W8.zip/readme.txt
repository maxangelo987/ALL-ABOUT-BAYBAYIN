(UNICODE) Baybayin Keyboard Layout for Windows 8

1) Click Setup.exe and follow the instructions. 
It�ll tell you your keyboard was installed successfully, but you won�t be able to use it until you restart.

2 )Restart the machine.
Once the machine is restarted, you should be good to go. 

3) On Windows 8, you just have to hit WinKey + Space to switch between the two or more keyboard layouts.

To be able to view Baybayin characters on the Windows 8 On-Screen Keyboard and Touch Keyboards, the default font Segoe UI needed a custom update.

4) Install the Segoe UI font (segoeui.ttf) over the excisting one in your machine.

a) Create a backup of your original segoeui.ttf file by copying/moving it to another folder other than the system's "windows/font" folder.
b) Left click or open the segoeui.ttf file that is included in this .zip file and look for the "install font" button/link.
c) Choose "Yes" if prompted to replace or overwrite the old Segoe UI font (if you left a copy in the windows/font folder). 

Note: When using Unicode Baybayin Fonts online, only the people who has a Unicode Baybayin compliant font in their machines can view what you typed/posted. For more information, visit: www.baybayinfonts.com

NORDENX (c) 2013